Create CRUD app with spring boot

![Alt text](image.png)

