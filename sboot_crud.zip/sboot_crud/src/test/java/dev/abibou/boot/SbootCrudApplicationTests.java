package dev.abibou.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
