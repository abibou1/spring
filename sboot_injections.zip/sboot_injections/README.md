Demo for field, setter, and constructor injections


![Alt text](image.png)