# pms

## Description
this application create, update, delete, search products in the Stock

![Alt text](image.png)