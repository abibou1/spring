package dev.abibou.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootWebApplication.class, args);
	}

}
