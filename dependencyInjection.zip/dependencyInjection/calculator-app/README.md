# Create basic Math operation app using Spring Framework with constructor injection

The data are passed through argument injection.

![Alt text](image.png)