# spring

Maven is used to create a spring application and dependency injection

![Alt text](image.png)