package factoryPattern;

public class MyDouble implements MyWrapper {

	@Override
	public void printType() {
		System.out.println("The value is of type: MyDouble");
	}
}
