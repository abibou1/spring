package factoryPattern;

public interface MyWrapper {
	void printType();
}
