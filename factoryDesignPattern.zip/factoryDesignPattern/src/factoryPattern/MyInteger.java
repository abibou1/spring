package factoryPattern;

public class MyInteger implements MyWrapper {

	@Override
	public void printType() {
		System.out.println("The value is of type: MyInteger");
	}

}
