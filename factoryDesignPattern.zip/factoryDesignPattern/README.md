# spring

Factory design pattern is used to determine the datatype of different variables.
An exception is thrown if the type is not among the predefined types.

![Alt text](image.png)